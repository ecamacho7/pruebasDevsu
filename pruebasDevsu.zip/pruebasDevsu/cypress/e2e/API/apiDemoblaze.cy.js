describe('Pruebas API DemoBlaze', () => {
    const baseUrl = 'https://api.demoblaze.com';

    it('Crear un nuevo usuario', () => {
    
        cy.request( {
            method: 'POST',
            url: ${baseUrl}/signup,
            body: {
                "username": "ecamachoc22",
                "password": "edwin123"
            }
        }).then(response => {
            expect(response.status).to.eq(200);
        });
    });

    it('Intentar crear usuario existente', () => {
        cy.request({
            method: 'POST',
            url: ${baseUrl}/signup,
            body: {
                "username": "ecamachoc22",
                "password": "edwin123"
            }
        }).then(response => {
            expect(response.status).to.eq(200);
            expect(response.body).to.have.property('errorMessage', "This user already exist.");
        });
    });

    it('Login con usuario y contraseña correctos', () => {
        cy.request({
            method: 'POST',
            url: ${baseUrl}/login,
            body: {
                "username": "ecamachoc22",
                "password": "edwin123"
            }
        }).then(response => {
            expect(response.status).to.eq(200);
            expect(response.body).to.include("Auth_token");
        });
    });

    it('Intento de login con usuario y contraseña incorrectos', () => {
        cy.request({
            method: 'POST',
            url: ${baseUrl}/login,
            body: {
                "username": "ecamachoc22",
                "password": "edwin123CAMACHO"
            }
        }).then(response => {
            expect(response.status).to.eq(200);
            expect(response.body).to.have.property('errorMessage', "Wrong password.");
        });
    });
});