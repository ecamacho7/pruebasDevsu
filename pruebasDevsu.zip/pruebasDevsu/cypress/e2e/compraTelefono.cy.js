const localizadoresCompraTelefono = require("../fixtures/localizadoresCompraTelefono.json");

describe('Prueba E2E Compra de telefonos', () => {
    it('should login and add a product to cart', () => {
        cy.visit('https://www.demoblaze.com/')
        cy.wait(3000)

        //agregar producto e ir al carrito
        cy.get("body > div:nth-child(6) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(1) > div:nth-child(1) > div:nth-child(2) > h4:nth-child(1) > a:nth-child(1)").click()
        cy.wait(3000)
        cy.get(".btn-success").click()
        cy.get("a[id='nava'] img").click()
        cy.get("body > div:nth-child(6) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > div:nth-child(1) > div:nth-child(2) > h4:nth-child(1) > a:nth-child(1)").click()
        cy.wait(3000)
        cy.get(".btn-success").click()

        //ir a completar datos
        cy.get("#cartur").click()
        cy.get(".btn-success").click()

        //completar datos
        cy.get(localizadoresCompraTelefono.name).type("edwin camacho")
        cy.get(localizadoresCompraTelefono.country).type("peru")
        cy.get(localizadoresCompraTelefono.city).type("lima")
        cy.get(localizadoresCompraTelefono.card).type("4111411141114111")
        cy.get(localizadoresCompraTelefono.month).type("febrero")
        cy.get(localizadoresCompraTelefono.year).type("2024")
        cy.get("#orderModal .btn-primary").click()

        //completar la compra
        cy.get(".sweet-alert > h2").should("be.visible").wait(1000);
        cy.get(".confirm").click({force:true});
    });
});