# Pruebas E2E y API con Cypress en Demoblaze

Este repositorio contiene pruebas de automatización E2E utilizando Cypress para la página web demoblaze.com.

## Instalación

1. Asegúrate de tener Node.js y npm instalados en tu sistema.
2. Clona este repositorio en tu máquina local.

##Ejecución

1. Ejecuta en la terminal el siguiente comando: npm run cypress:open
2. Ejecuta el archivo requerido.